/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0A1229',
          light: '#111C35'
        },
        accent: {
          DEFAULT: '#3B82F6',
          hover: '#2563EB',
          glow: '#60A5FA'
        },
        text: {
          primary: '#F8FAFC',
          secondary: '#94A3B8'
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif']
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-slow': 'bounce 3s infinite'
      }
    },
  },
  plugins: [],
};