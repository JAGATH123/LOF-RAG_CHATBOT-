import React, { useState } from 'react';
import { Send, Bot, User, MessageCircle, X } from 'lucide-react';

interface Message {
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface QuickAction {
  text: string;
  action: () => void;
}

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hi there! 👋 I'm your AI assistant for space and robotics education. How can I help you today?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const quickActions: QuickAction[] = [
    {
      text: "What courses do you offer?",
      action: () => handleQuickAction("What courses do you offer?")
    },
    {
      text: "How do I enroll?",
      action: () => handleQuickAction("How do I enroll?")
    },
    {
      text: "Do you offer financial aid?",
      action: () => handleQuickAction("Do you offer financial aid?")
    },
    {
      text: "Can I get a course syllabus?",
      action: () => handleQuickAction("Can I get a course syllabus?")
    }
  ];

  const handleQuickAction = (text: string) => {
    const newMessage: Message = {
      text,
      sender: 'user',
      timestamp: new Date()
    };
    setMessages([...messages, newMessage]);
    
    setIsTyping(true);
    setTimeout(() => {
      const botResponse: Message = {
        text: "I'm a demo bot. The actual implementation will connect to your backend!",
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSend = () => {
    if (input.trim()) {
      const newMessage: Message = {
        text: input,
        sender: 'user',
        timestamp: new Date()
      };
      setMessages([...messages, newMessage]);
      setInput('');
      
      setIsTyping(true);
      setTimeout(() => {
        const botResponse: Message = {
          text: "I'm a demo bot. The actual implementation will connect to your backend!",
          sender: 'bot',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botResponse]);
        setIsTyping(false);
      }, 1500);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-accent hover:bg-accent-hover text-white p-4 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
        >
          <MessageCircle size={24} />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="bg-primary rounded-2xl shadow-xl w-[360px] h-[600px] flex flex-col">
          {/* Header */}
          <div className="bg-primary-light p-4 rounded-t-2xl border-b border-accent/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="text-accent" size={24} />
              <h2 className="font-semibold">AI Education Assistant</h2>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-text-secondary hover:text-text-primary transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex items-start gap-2 ${
                  message.sender === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  message.sender === 'user' 
                    ? 'bg-accent' 
                    : 'bg-primary-light border border-accent/20'
                }`}>
                  {message.sender === 'user' ? (
                    <User size={16} />
                  ) : (
                    <Bot size={16} />
                  )}
                </div>
                <div
                  className={`rounded-xl p-3 max-w-[75%] ${
                    message.sender === 'user'
                      ? 'bg-accent'
                      : 'bg-primary-light border border-accent/20'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-start gap-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-primary-light border border-accent/20">
                  <Bot size={16} />
                </div>
                <div className="bg-primary-light border border-accent/20 rounded-xl p-3">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          {messages.length === 1 && (
            <div className="px-4 pb-4 grid grid-cols-1 gap-2">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={action.action}
                  className="p-2 text-sm text-left rounded-lg bg-primary-light border border-accent/20 hover:border-accent/40 hover:bg-accent/5 transition-all duration-200"
                >
                  {action.text}
                </button>
              ))}
            </div>
          )}

          {/* Input Area */}
          <div className="p-4 border-t border-accent/10">
            <div className="flex items-center gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 bg-primary-light border border-accent/20 rounded-lg p-2 text-sm resize-none focus:outline-none focus:border-accent/40"
                rows={1}
              />
              <button
                onClick={handleSend}
                className="p-2 rounded-lg bg-accent hover:bg-accent-hover transition-all duration-200"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;